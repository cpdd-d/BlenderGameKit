"""导出资产到 Godot:glTF(.glb) + 场景(.tscn) + 材质(.tres)。

为什么需要它
------------
Blender 里的模型不能"自带脚本"。Godot 的脚本只能挂在**节点**上，
而 .glb 导入后只是一个网格节点。所以正确的做法是把三件事分开:

    模型      Blender 网格/骨骼/动画  --glTF-->  .glb          (几何)
    材质      Blender 材质            --生成-->  .tres + .gdshader (外观)
    行为      节点图                  --生成-->  .gd            (逻辑)
    装配      ----  生成的 .tscn 把上面三者拼在一起  ----        (节点树)

这个模块负责"装配":导出 .glb，生成引用它的 .tscn，并把脚本挂到根节点上。
这样在 Godot 里打开就是"模型 + 碰撞体 + 脚本 + 卡通材质"的完整角色。

贴图怎么办
----------
glTF 会把贴图**内嵌**进 .glb(默认)或导出为外部文件。两种都能被 Godot 直接读。
Blender 里材质的 Base Color 贴图会变成 Godot 的 albedo_texture，
所以本插件生成的卡通材质会自动带上它(见 _base_color_texture)。
"""

import os
import re

from . import gk_log
from . import npr_preview
from . import project
from .nodes.node_base import gd_node_path, snake_case

# 导出的 .tscn 里，脚本与模型各自的 res:// 路径
SCENE_TEMPLATE = """[gd_scene load_steps={steps} format=3]

[ext_resource type="Script" path="{script_path}" id="1_script"]
[ext_resource type="PackedScene" path="{model_path}" id="2_model"]
{sub_resources}
[node name="{root_name}" type="{base_class}"]
script = ExtResource("1_script")
{collision}
[node name="Model" parent="." instance=ExtResource("2_model")]
{environment}
"""

# 相机 + 灯光的节点文本。
#
# 为什么角色场景也要带这些:用户按 F5 跑起来看到的是**一片灰**,
# 因为角色场景里只有网格 —— 没有相机就没有视点,没有灯光就全黑,
# 再加上没有环境就是 Godot 默认的灰底。这不是"渲染坏了",是场景里确实空。
# 从 Blender 场景里把相机和灯光搬过来,打开就能看见东西。
# glb 里没有相机时兜底用的节点。
# 名字用 Blender 里的原名 —— 硬编码叫 "Camera" 的话会和 glb 里的对不上,
# 看起来就像凭空多了一个。
ENVIRONMENT_CAMERA = """
[node name="{name}" type="Camera3D" parent="."]
transform = Transform3D({basis}, {cx}, {cy}, {cz})
fov = {fov:.2f}
current = true
"""

ENVIRONMENT_LIGHT = """
[node name="{name}" type="DirectionalLight3D" parent="."]
transform = Transform3D({basis}, {lx}, {ly}, {lz})
light_energy = {energy:.3f}
"""

# 让 glb 里带进来的相机成为主相机。
#
# ── 为什么需要这一步 ────────────────────────────────────────────
# glTF 会带相机(写进 cameras 数组),Godot 导入后自动生成 Camera3D,
# 位置朝向都对的。但**不会**把它设成 current ——
# 实测:没有这一步时 `get_root().get_camera_3d()` 返回 null,
# 按 F5 用的是默认视点,画面还是一片灰。
#
# ── 为什么用脚本而不是再写一个 Camera3D 节点 ────────────────────
# 直接再生成一个节点的话,场景里就有两个相机了。实测踩过:
# 用户在 Godot 里看到"多一个摄像头",而且分不清哪个是 Blender 的。
#
# 用 @tool 脚本挂在唯一的 Environment 节点上:单实例、幂等。
# 而且挂在 `_ready` 上,每次打开编辑器/运行都会重新指向正确的那个 ——
# 用户之后手动改主相机也不会被永久覆盖,下次导出再指回来。
ENVIRONMENT_SCRIPT = '''@tool
extends Node
## BlenderGameKit 生成:修好相机和灯光。
##
## 改这里没有用 —— 下次从 Blender 导出会被覆盖。
##
## ── 为什么需要这个脚本 ──────────────────────────────────────────
##
## 1) **相机**:glTF 会带相机过来(位置朝向都对),但**不会**设成
##    current —— 不设的话按 F5 看到的是默认视点,通常一片灰。
##
## 2) **灯光过曝**:Blender 的太阳导出成 glTF 后强度是**坎德拉**级别的
##    大数字(太阳强度 3.0 会变成 2049),Godot 原样接收,
##    于是画面被冲成**纯白** —— 看起来就像"材质没生效"。
##    实测:energy=2049 时画面只有 1 种颜色;改成 1.0 之后 71 种。
##    这个坑排查了很久,所以这里按 Blender 的强度重新算一遍。

## Blender 里主相机的名字。
@export var camera_name: String = "{camera_name}"

## Blender 相机的垂直视场角(度)。<= 0 表示不改。
@export var camera_fov: float = {fov}

## Blender 里太阳的强度。<= 0 表示不碰灯光。
@export var sun_strength: float = {sun_strength}

## Godot 里灯光的 light_energy。<= 0 表示不碰。
## 这是**用户在 Blender 面板里直接调的值**,优先于 sun_strength 的换算。
@export var light_energy: float = {light_energy}

## 灯光颜色。
@export var light_color: Color = Color({lr}, {lg}, {lb}, 1)

## 是否投射阴影。
@export var light_shadows: bool = {light_shadows}

## 额外旋转(水平方位角,度)。0 = 完全照搬 Blender 里的灯光朝向。
@export var light_azimuth: float = {light_azimuth}

## 材质映射:"节点名=材质路径" 用换行分隔。
## 形如 "Ball=res://materials/Ballmat.tres"
@export_multiline var materials: String = "{materials}"

## 灯光表:每行一盏灯,字段用 | 分隔:
##   类型|名字|x|y|z|基向量(9个数,逗号分隔)|能量|r|g|b|阴影|范围|锥角
##
## 为什么不用 glTF 自带的灯:glTF 的 KHR_lights_punctual 只有平行光能用得好,
## 点光/聚光的能量单位对不上(坎德拉 vs 流明),面光更是直接丢失。
@export_multiline var lights_table: String = "{lights}"

## 灯光表:每行一盏灯,字段用 | 分隔:
##   类型|名字|x|y|z|基向量(9个数,逗号分隔)|能量|r|g|b|阴影|范围|锥角
@export_multiline var lights: String = "{lights}"


func _ready() -> void:
	_activate_camera()
	_fix_lights()
	_apply_materials()
	# 建灯必须**延迟**到本帧的节点装配结束之后。
	#
	# 踩过:`_ready()` 里直接 add_child 会被 Godot 拒绝 ——
	#     ERROR: Parent node is busy setting up children, `add_child()` failed.
	# 结果灯对象建出来了、日志也打了,但一个都没进场景树,画面全黑。
	# 用 call_deferred 排到本帧末尾就没这个问题。
	_build_lights.call_deferred()


## 把 Blender 里调好的卡通材质挂到对应的网格上。
##
## 为什么要在运行时装,而不是写进 .tscn:
## glb 实例的**内部子节点不能被外部节点覆盖** —— 在 .tscn 里写
##     [node name="Ball" parent="World"]
##     material_override = ExtResource("mat_2")
## Godot 会报 "Parent path './World' for node 'Ball' has vanished",
## 覆盖被丢弃,看到的永远是白模。加 editable_children 也没用。
## 运行时装是有效的(实测)。
func _apply_materials() -> void:
	if materials.strip_edges().is_empty():
		return
	var root := _scene_root()
	if root == null:
		return
	var applied := 0
	for line in materials.split("\\n", false):
		var text := line.strip_edges()
		if text.is_empty() or not text.contains("="):
			continue
		var parts := text.split("=", true, 1)
		var node_name := parts[0].strip_edges()
		var res_path := parts[1].strip_edges()
		if not ResourceLoader.exists(res_path):
			push_warning("[GK] 材质不存在: " + res_path)
			continue
		var material: Material = load(res_path)
		if material == null:
			continue
		var node := root.find_child(node_name, true, false)
		if node is MeshInstance3D:
			(node as MeshInstance3D).material_override = material
			applied += 1
		else:
			push_warning("[GK] 没找到网格节点: " + node_name)
	if applied > 0:
		print("[GK] 已挂 ", applied, " 个卡通材质")


func _activate_camera() -> void:
	if camera_name.is_empty():
		return
	var found := _find_camera()
	if found == null:
		push_warning("[GK] 没找到相机节点: " + camera_name)
		return
	if camera_fov > 0.0:
		found.fov = camera_fov
	found.make_current()


## 把 glb 带进来的灯光改掉。
##
## 为什么要"改"而不是"留着":
##   * glTF 导出的强度是坎德拉级的大数字(Blender 日光 3.0 -> 2049),
##     Godot 原样接收会把画面冲成纯白 —— 看起来就像"材质没生效"。
##   * 点光和聚光在 glTF 里单位也对不上(坎德拉 vs 流明)。
## 所以这里统一按 Blender 侧的设置重算。
##
## 真正的灯由 _build_lights() 生成;glb 带进来的那些**关掉**,
## 免得两套灯叠在一起变成双倍亮度。
func _fix_lights() -> void:
	var lights := _scene_root().find_children("*", "Light3D", true, false)
	if lights.is_empty():
		return

	# 目标亮度:用户直接指定了就用他的;没指定才按 Blender 的太阳强度换算。
	#
	# 换算依据(实测标定):Blender 太阳强度 3.0 导出后在 Godot 里是 26.09,
	# 而画面正常的量级是 1 左右,所以除以 8.7。
	var target: float = light_energy
	if target <= 0.0:
		if sun_strength <= 0.0:
			target = 0.0
		else:
			target = clampf(sun_strength / 8.7, 0.1, 2.0)

	for node in lights:
		var light := node as Light3D
		if light == null:
			continue
		# 有灯光表时,这些 glb 带的灯全部关闭 —— 由 _build_lights 重建
		if not lights_table.is_empty():
			light.visible = false
			light.light_energy = 0.0
			continue
		light.light_energy = target
		light.light_color = light_color
		light.shadow_enabled = light_shadows
		if absf(light_azimuth) > 0.001:
			light.rotate_y(deg_to_rad(light_azimuth))


## 按灯光表生成真正的 Godot 灯节点。
##
## 为什么不让 glTF 自己带:glTF 的 KHR_lights_punctual 只有平行光能用得好 ——
## 点光和聚光的能量单位对不上(坎德拉 vs 流明),Blender 的面光更是直接丢失。
## 所以这里按 Blender 侧的设置建节点,灯型由用户在面板里定。
func _build_lights() -> void:
	if lights_table.strip_edges().is_empty():
		print("[GK] 灯光表是空的,不建灯")
		return
	var root := _scene_root()
	if root == null:
		push_warning("[GK] 找不到场景根节点,建不了灯")
		return
	print("[GK] 挂灯到 ", root.get_path() if root.is_inside_tree() else root.name)
	var holder := Node3D.new()
	holder.name = "Lights"
	root.add_child(holder)
	print("[GK] Lights 已挂: ", holder.get_path())

	var built := 0
	for raw in lights_table.split("\\n", false):
		var line := raw.strip_edges()
		if line.is_empty():
			continue
		var f := line.split("|")
		if f.size() < 12:
			continue
		var kind := f[0]
		var node: Light3D = null
		match kind:
			"directional":
				node = DirectionalLight3D.new()
			"omni", "area_omni":
				node = OmniLight3D.new()
			"spot":
				node = SpotLight3D.new()
			_:
				continue
		node.name = f[1]
		var x := float(f[2])
		var y := float(f[3])
		var z := float(f[4])
		var basis := f[5].split(",")
		if basis.size() >= 9:
			var b := Basis()
			b.x = Vector3(float(basis[0]), float(basis[1]), float(basis[2]))
			b.y = Vector3(float(basis[3]), float(basis[4]), float(basis[5]))
			b.z = Vector3(float(basis[6]), float(basis[7]), float(basis[8]))
			node.transform = Transform3D(b, Vector3(x, y, z))
		else:
			node.position = Vector3(x, y, z)
		node.light_energy = float(f[6])
		node.light_color = Color(float(f[7]), float(f[8]), float(f[9]), 1.0)
		node.shadow_enabled = f[10] == "1"
		var radius := float(f[11])
		if node is OmniLight3D and radius > 0.0:
			(node as OmniLight3D).omni_range = radius
		elif node is SpotLight3D:
			if radius > 0.0:
				(node as SpotLight3D).spot_range = radius
			if f.size() >= 13:
				(node as SpotLight3D).spot_angle = float(f[12])
		holder.add_child(node)
		built += 1
	if built > 0:
		print("[GK] 生成了 ", built, " 盏灯")


## 找"场景根节点"。
##
## ── 这里踩了两个坑,都记下来 ────────────────────────────────────
##
## 坑 1:不能用 `get_node_or_null(camera_name)` 找相机 ——
## 那是**相对本节点**的路径,而相机和本节点是兄弟,必然找不到。
## 所以下面用 find_child 从场景根往下搜。
##
## 坑 2:**不能只靠 `get_tree().current_scene`**。
## 用 `godot --script` 跑探测脚本时它返回的是**窗口根节点**(/root),
## 于是灯被挂成了 `/root/Lights` 而不是 `<场景>/Lights` ——
## 看起来"生成了 4 盏灯"却一盏都找不到(实测排查了很久)。
##
## 正确做法:从自己往上走,找到最上面那个**有父节点的**节点,
## 也就是场景实例的根(它挂在 /root 下面)。
func _scene_root() -> Node:
	var node: Node = self
	while node.get_parent() != null and node.get_parent().get_parent() != null:
		node = node.get_parent()
	return node


func _find_camera() -> Camera3D:
	var root := _scene_root()
	if root == null:
		return null
	if not camera_name.is_empty():
		var direct := root.find_child(camera_name, true, false)
		if direct is Camera3D:
			return direct as Camera3D
	for node in root.find_children("*", "Camera3D", true, false):
		if node is Camera3D:
			return node as Camera3D
	return null
'''

ENVIRONMENT_NODE = """
[node name="Environment" type="Node" parent="."]
script = ExtResource("env_script")
camera_name = "{camera_name}"
camera_fov = {fov}
sun_strength = {sun_strength}
light_energy = {light_energy}
light_color = Color({lr}, {lg}, {lb}, 1)
light_shadows = {light_shadows}
light_azimuth = {light_azimuth}
materials = "{materials}"
lights_table = "{lights}"
"""

COLLISION_TEMPLATE = """
[sub_resource type="CapsuleShape3D" id="cap3d"]
radius = {radius:.4f}
height = {height:.4f}

[sub_resource type="CapsuleShape2D" id="cap2d"]
radius = {radius:.4f}
height = {height:.4f}
"""

COLLISION_NODE_3D = """
[node name="Collision" type="CollisionShape3D" parent="."]
shape = SubResource("cap3d")
"""

COLLISION_NODE_2D = """
[node name="Collision" type="CollisionShape2D" parent="."]
shape = SubResource("cap2d")
"""

TOON_MATERIAL_TEMPLATE = """[gd_resource type="ShaderMaterial" load_steps={steps} format=3]

[ext_resource type="Shader" path="{shader_path}" id="1_shader"]
{outline_ext}{textures}
{outline_sub}[resource]
shader = ExtResource("1_shader")
{outline_pass}shader_parameter/albedo_color = Color({r:.4f}, {g:.4f}, {b:.4f}, 1)
shader_parameter/use_albedo_texture = {use_texture:.1f}
shader_parameter/albedo_strength = 1.0
shader_parameter/albedo_texture = {albedo_ref}
shader_parameter/light_map_mix = 0.0
shader_parameter/shadow_step = 0.1
shader_parameter/shadow_smooth = 0.02
shader_parameter/three_tone = 0.0
shader_parameter/lit_tint = Color(1, 0.976, 0.914, 1)
shader_parameter/shadow_tint = Color(0.706, 0.627, 0.902, 1)
shader_parameter/shadow_strength = 1.0
shader_parameter/specular_amount = 0.2
shader_parameter/rim_amount = 0.4
shader_parameter/backlight_amount = 0.0
shader_parameter/emission_amount = 0.0
{outline_param}"""

# 描边的 next_pass。
#
# ── 为什么描边要单独一个 pass ────────────────────────────────────
# 描边是"反面外扩"(inverted hull):把模型沿法线撑开一点、只画背面。
# 这是个**几何**操作,和卡通着色完全是两件事,塞不进同一个 shader ——
# 同一个网格不可能既按原样画、又撑开画。
# Godot 的 next_pass 正好是干这个的:同一个网格再走一遍另一个材质。
#
# ── 顺序要求(踩过)────────────────────────────────────────────────
# sub_resource 必须在**引用它之前**定义。Godot 解析 .tscn/.tres 是按出现顺序
# 登记 sub_resource 的,先引用后定义会报 ERR_INVALID_PARAMETER 然后整个
# 资源加载失败。
OUTLINE_EXT_RESOURCE = (
    '[ext_resource type="Shader" path="{outline_shader}" id="2_outline"]\n'
)
OUTLINE_SUB_RESOURCE = """[sub_resource type="ShaderMaterial" id="outline_pass"]
shader = ExtResource("2_outline")
shader_parameter/outline_color = Color({cr:.4f}, {cg:.4f}, {cb:.4f}, 1)
shader_parameter/outline_width = {width:.4f}
shader_parameter/outline_screen_constant = {screen_constant:.1f}
shader_parameter/outline_silhouette_boost = {boost:.2f}
shader_parameter/jitter_enable = {jitter:.1f}
shader_parameter/jitter_fps = {jitter_fps:.1f}
shader_parameter/jitter_width = {jitter_width:.2f}
shader_parameter/jitter_offset = {jitter_offset:.4f}

"""
OUTLINE_NEXT_PASS = 'next_pass = SubResource("outline_pass")\n'


def safe_name(text, fallback="model"):
    name = re.sub(r"[^A-Za-z0-9_\-]", "", snake_case(text or "", ""))
    return name or fallback


# 碰撞预览物体的标记属性。
# 用自定义属性而不是名字前缀来识别 —— 用户可能给物体起任何名字,
# 靠名字判断会误删。导出时也靠它来排除预览线框。
PREVIEW_MARK = "gk_collision_preview"

# 工具生成的辅助材质都以此为前缀(描边预览材质等)。
# 导出时要跳过它们 —— 否则用户会看到自己的模型在 Godot 里变成纯黑壳。
TOOL_MATERIAL_PREFIX = "__GK"


def collect_objects(context):
    """要导出的对象:优先用选中的，没选就全部可见网格。"""
    selected = [obj for obj in context.selected_objects if obj.type == "MESH"]
    if selected:
        return selected, "selected"
    visible = [obj for obj in context.scene.objects if obj.type == "MESH" and not obj.hide_get()]
    return visible, "visible"


def object_bounds(objects):
    """所有网格的世界空间包围盒，用来生成合适的碰撞体尺寸。"""
    import mathutils

    mins = mathutils.Vector((1e9, 1e9, 1e9))
    maxs = mathutils.Vector((-1e9, -1e9, -1e9))
    found = False
    for obj in objects:
        for corner in obj.bound_box:
            world = obj.matrix_world @ mathutils.Vector(corner)
            for axis in range(3):
                mins[axis] = min(mins[axis], world[axis])
                maxs[axis] = max(maxs[axis], world[axis])
            found = True
    if not found:
        return None
    size = maxs - mins
    center = (maxs + mins) * 0.5
    return {"min": tuple(mins), "max": tuple(maxs), "size": tuple(size), "center": tuple(center)}


def export_glb(export_dir, name, use_selection, objects):
    """调用 Blender 的 glTF 导出。返回 (路径, 是否成功, 消息)。"""
    import bpy

    # 模型统一放 art/,和贴图在一起
    target_dir = os.path.join(export_dir, project.ART_DIR)
    os.makedirs(target_dir, exist_ok=True)
    path = os.path.join(target_dir, f"{name}.glb")
    kwargs = {
        "filepath": path,
        "export_format": "GLB",
        "use_selection": bool(use_selection),
        "export_apply": True,
        "export_yup": True,
        "export_materials": "EXPORT",
        "export_animations": True,
        "export_skins": True,
        "export_texcoords": True,
        "export_normals": True,
    }
    return _run_gltf_export(kwargs, path)


def export_scene_glb(export_dir, name="World", scene=None):
    """把**整个 Blender 场景**导出成一个 .glb(保持层级与变换)。

    返回 (路径, 是否成功, 消息)。

    ── 为什么需要单独做这个 ────────────────────────────────────────
    之前的导出是"把选中的网格导出成一个模型",适合角色。
    但要"打开 Godot 时看到的场景和 Blender 里一样",就必须导出**整个场景的
    层级结构**:空物体、父子关系、每件东西的位置。

    glTF 本身就支持层级,Blender 的导出器会把:
        * 对象父子关系  -> 节点的父子关系
        * 对象变换      -> 节点变换(并且自动做 Z-up -> Y-up 转换)
        * 灯光 / 相机   -> 灯光节点 / 相机节点
    都带过去。所以这一个文件就能让 Godot 里的场景和 Blender 一致。

    ── 预览物体必须手动排除 ────────────────────────────────────────
    碰撞线框预览设了 hide_render,**但 glTF 导出器不看这个** ——
    实测三个 `__GK碰撞预览__` 物体全都进了 .glb。
    所以这里在导出前显式把它们取消选中(导出器会跳过未选中对象),
    导出后再恢复原来的选中状态。
    """
    import bpy

    scene = scene or bpy.context.scene
    if scene is None:
        return None, False, "没有场景"

    # 记住原来的选中状态,导出后恢复 —— 不要打乱用户的选择
    previous = [obj for obj in scene.objects if obj.select_get()]

    skipped = []
    for obj in scene.objects:
        if obj.get(PREVIEW_MARK):
            skipped.append(obj.name)
            obj.select_set(False)
        else:
            obj.select_set(not obj.hide_get())

    target_dir = os.path.join(export_dir, project.ART_DIR)
    os.makedirs(target_dir, exist_ok=True)
    path = os.path.join(target_dir, f"{name}.glb")

    kwargs = {
        "filepath": path,
        "export_format": "GLB",
        "use_selection": True,      # 配合上面的取消选中来排除预览物体
        "export_apply": False,
        "export_yup": True,
        "export_materials": "EXPORT",
        "export_animations": True,
        "export_skins": True,
        "export_texcoords": True,
        "export_normals": True,
        "export_cameras": True,
        "export_lights": True,
        "export_extras": True,
    }
    result = _run_gltf_export(kwargs, path)

    # 恢复选中状态
    try:
        for obj in scene.objects:
            obj.select_set(obj in previous)
    except Exception:
        pass

    if result[1] and skipped:
        return result[0], True, (f"已导出 {os.path.basename(path)}"
                                 f"（已排除 {len(skipped)} 个碰撞预览）")
    return result


def _run_gltf_export(kwargs, path):
    """跑 glTF 导出,参数名不兼容时逐个降级重试。"""
    import bpy

    working = dict(kwargs)
    for _ in range(12):
        try:
            bpy.ops.export_scene.gltf(**working)
            if os.path.isfile(path):
                return path, True, f"已导出 {os.path.basename(path)}"
            return path, False, "导出命令执行了，但文件没生成"
        except TypeError as exc:
            message = str(exc)
            dropped = None
            for key in list(working):
                if key in message and key != "filepath":
                    dropped = key
                    break
            if dropped is None:
                return path, False, f"导出参数不被支持: {message}"
            working.pop(dropped, None)
        except Exception as exc:
            return path, False, f"导出失败: {exc}"
    return path, False, "重试次数用尽"


def write_world_scene(export_dir, scene_name="World", scene=None,
                      dimension="3", script_name=None, script_target_name=None,
                      materials_map=None):
    """生成主场景:模型 + 卡通材质 + 碰撞体 + 相机灯光。返回 (路径, 碰撞体数量)。

    结构(3D):

        Ball      [MeshInstance3D]   mesh = glb 里的 BallMesh
                                     material_override = materials/Ballmat.tres
        Floor     [MeshInstance3D]
        ShotCam   [Camera3D]
        KeySun    [DirectionalLight3D]
        Colliders [Node3D]
          Ball    [StaticBody3D]
            Collision [CollisionShape3D]

    ── 材质怎么挂(这条路踩了很久)────────────────────────────────────
    试过三种写法,只有第三种能工作:

    1) 给 glb 实例内部的子节点写 material_override:
           [node name="World" instance=ExtResource("1_world")]
           [node name="Ball" parent="World"]
           material_override = ExtResource("mat_2")
       **不生效**。Godot 报
           WARNING: Parent path './World' for node 'Ball' has vanished
       覆盖被丢弃,用户看到的永远是白模。加 editable_children = true 也没用。

    2) 把网格展开成 MeshInstance3D,`mesh = ExtResource("mesh_1")`:
       **不生效**。运行时 `mi.mesh` 是 `<Object#null>` ——
       glb 的网格没有按 `文件.glb/网格名` 暴露成可引用资源,画不出东西,
       画面一片纯灰。

    3) **instance 整个 glb + 运行时用脚本挂材质** ← 现在用的
       .tscn 里只 instance glb(几何/层级/变换一定对),
       材质映射交给 Environment 脚本在 `_ready` 里挂。
       实测 StandardMaterial3D 和 ShaderMaterial 都能成功显示。

    materials_map: {对象名: (材质资源名, materials/ 下的文件名)}
    """
    path = os.path.join(export_dir, project.SCENES_DIR, f"{scene_name}.tscn")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    is_3d = str(dimension) != "2"

    info = glb_scene_nodes(export_dir, scene_name)
    mesh_info = info.get("meshes", {})
    if not mesh_info:
        return None, 0

    # glb 实例本身
    ext_lines = [
        f'[ext_resource type="PackedScene" '
        f'path="res://{project.ART_DIR}/{scene_name}.glb" id="1_world"]'
    ]

    use_script = bool(script_name and script_target_name)
    script_id = None
    if use_script:
        script_id = "gk_script"
        ext_lines.append(f'[ext_resource type="Script" '
                         f'path="res://{project.SCRIPTS_DIR}/{script_name}" '
                         f'id="{script_id}"]')

    # ---- 碰撞体 ----
    bodies = []
    sub_resources = []
    if scene is not None:
        for index, (obj, physics, enabled) in enumerate(collect_physics(scene)):
            if not enabled or getattr(obj, "type", "") != "MESH":
                continue
            built = build_collision(obj, is_3d, physics)
            if built is None:
                continue
            shape_id = f"shape_{index}"
            sub_resources.append(
                built["sub_resource"].replace('id="shape"', f'id="{shape_id}"'))
            bodies.append((obj, physics, built, shape_id,
                           _godot_position(obj, is_3d)))

    # ---- 相机 / 灯光 / Environment ----
    # (见上面"材质怎么挂"里的说明:相机和灯由 glb 带进来,
    #  Environment 脚本负责设主相机、修灯光亮度、挂材质)
    glb_info = glb_object_names(export_dir, scene_name)
    material_files = {}
    for obj_name in sorted(mesh_info):
        entry = (materials_map or {}).get(obj_name)
        if entry:
            material_files[obj_name] = entry[1]

    environment, env_files, _camera_name = build_environment_nodes(
        scene, is_3d, skip=glb_info, scene_name=scene_name,
        material_files=material_files)
    if env_files:
        ext_lines.append(f'[ext_resource type="Script" '
                         f'path="res://{project.SCRIPTS_DIR}/gk_environment.gd" '
                         f'id="env_script"]')

    load_steps = 1 + len(ext_lines) + len(sub_resources)

    lines = [f"[gd_scene load_steps={load_steps} format=3]", ""]
    lines.extend(ext_lines)
    lines.append("")
    for block in sub_resources:
        lines.append(block)
        lines.append("")

    for relative, content in (env_files or {}).items():
        target = os.path.join(export_dir, relative)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)

    # ---- 根节点下的 glb 实例 ----
    #
    # ── 为什么不把网格展开成一个个 MeshInstance3D ────────────────────
    # 试过那种做法(`mesh = ExtResource("mesh_1")`,指向 glb 里的网格),
    # **Godot 拿不到那个资源** —— 运行时 `mi.mesh` 是 `<Object#null>`,
    # 于是什么都画不出来,画面一片纯灰。
    # glb 的网格没有按 `文件.glb/网格名` 这种形式暴露成可引用的资源。
    #
    # 所以还是 instance 整个 glb:几何、层级、变换都由它负责,一定是对的。
    lines.append(f'[node name="{scene_name}" '
                 f'instance=ExtResource("1_world")]')
    lines.append("")

    # ── 材质:交给运行时脚本挂 ──────────────────────────────────────
    # 不能在 .tscn 里给实例内部的子节点写 material_override ——
    # Godot 报 `Parent path './World' for node 'Ball' has vanished`,
    # 覆盖不生效,用户看到的永远是白模。加 editable_children 也没用。
    #
    # 但**运行时**挂是生效的(实测:StandardMaterial3D 和 ShaderMaterial
    # 都成功显示)。所以把映射表交给 Environment 脚本去挂。
    material_files = {}
    for obj_name in sorted(mesh_info):
        entry = (materials_map or {}).get(obj_name)
        if entry:
            material_files[obj_name] = entry[1]

    # ---- 相机 / 灯光 ----
    #
    # glTF 自带的相机和灯由 glb 实例带进来,不再另外生成节点
    # (生成的话场景里会有两个相机,用户会说"多一个摄像头")。
    # Environment 脚本负责把相机设成 current 并按 Blender 的强度修正灯光。
    environment, env_files, _camera_name = build_environment_nodes(
        scene, is_3d, skip=glb_info, scene_name=scene_name,
        material_files=material_files)
    if env_files:
        ext_lines.append(f'[ext_resource type="Script" '
                         f'path="res://{project.SCRIPTS_DIR}/gk_environment.gd" '
                         f'id="env_script"]')

    # ---- 碰撞体 ----
    if bodies:
        lines.append('[node name="Colliders" type="Node3D" parent="."]')
        lines.append("")
        for obj, physics, built, shape_id, position in bodies:
            body_type = getattr(physics, "body_type", None) or "StaticBody3D"
            if getattr(physics, "is_trigger", False):
                body_type = "Area3D" if is_3d else "Area2D"
            lines.append(f'[node name="{_sanitize_node_name(obj.name)}" '
                         f'type="{body_type}" parent="Colliders"]')
            # 位置必须写出来:碰撞体在这个世界坐标上,不写就全堆在原点,
            # 完全对不上模型(实测踩过,Godot 里读回来全是 0)。
            lines.append(f"transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, "
                         f"{_fmt(position[0])}, {_fmt(position[1])}, "
                         f"{_fmt(position[2])})")
            if use_script and getattr(physics, "script_target", False):
                lines.append(f'script = ExtResource("{script_id}")')
            lines.append("")
            shape_type = "CollisionShape3D" if is_3d else "CollisionShape2D"
            lines.append(f'[node name="Collision" type="{shape_type}" '
                         f'parent="Colliders/{_sanitize_node_name(obj.name)}"]')
            lines.append(f'shape = SubResource("{shape_id}")')
            layer = built["layer"]
            mask = built["mask"]
            if layer != "1" or mask != "1":
                lines.append(f"collision_layer = {int(layer)}")
                lines.append(f"collision_mask = {int(mask)}")
            lines.append("")

    if environment:
        lines.append(environment.strip("\n"))
        lines.append("")

    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines))

    project.set_main_scene(export_dir, f"{project.SCENES_DIR}/{scene_name}.tscn")
    return path, len(bodies)


_IDENTITY = ("1.000000, 0.000000, 0.000000, "
             "0.000000, 1.000000, 0.000000, "
             "0.000000, 0.000000, 1.000000, "
             "0.000000, 0.000000, 0.000000")


def _glb_node_details(export_dir, model_name):
    """从 glb 里取出每个节点(网格/相机/灯)的变换。

    返回 (网格变换, [(相机名, 变换, 垂直FOV)], [(灯名, 变换)])。

    必须算完整的 TRS 矩阵,不能只写平移 —— 相机和太阳的朝向全靠旋转,
    只写平移的话它们会一起朝上/朝前,画面立刻不对。
    """
    import json
    import math
    import struct

    matrices = {}
    cameras = []
    lights = []
    path = os.path.join(export_dir or "", project.ART_DIR, f"{model_name}.glb")
    if not os.path.isfile(path):
        return matrices, cameras, lights
    try:
        with open(path, "rb") as handle:
            data = handle.read()
        offset = 12
        payload = None
        while offset < len(data):
            length, kind = struct.unpack_from("<II", data, offset)
            offset += 8
            if kind == 0x4E4F534A:
                payload = json.loads(data[offset:offset + length].decode("utf-8"))
                break
            offset += length
        if payload is None:
            return matrices, cameras, lights
    except (OSError, ValueError, struct.error):
        return matrices, cameras, lights

    camera_defs = payload.get("cameras", [])
    for node in payload.get("nodes", []):
        name = node.get("name", "")
        matrix = _glb_node_matrix(payload, node)
        if "mesh" in node:
            matrices[name] = matrix
        elif "camera" in node:
            fov = 0.0
            index = node["camera"]
            if index < len(camera_defs):
                perspective = camera_defs[index].get("perspective", {})
                if "yfov" in perspective:
                    fov = math.degrees(float(perspective["yfov"]))
            cameras.append((name, matrix, fov))
        elif node.get("extensions", {}).get("KHR_lights_punctual"):
            lights.append((name, matrix))
    return matrices, cameras, lights

def glb_object_names(export_dir, model_name="World"):
    """读 .glb 里有哪些对象,以及有没有相机/灯。

    为什么要读它:**glTF 本身就能带相机和灯**(Blender 导出时会带上,
    相机走 GLTF 的 cameras 数组,灯走 KHR_lights_punctual 扩展),
    Godot 导入后会**自动**生成对应的 Camera3D / DirectionalLight3D。
    如果我们再额外生成一份,场景里就会出现两个相机、两盏灯。

    实测踩过:World.glb 里有 4 个节点(Plane/Cube/Camera/Sun),
    包装场景里又生成了一个 Camera 和一个 Sun —— 用户在 Godot 里
    看到"多一个摄像头",而且分不清哪个是 Blender 的。

    返回 {"nodes": [...], "cameras": [...], "lights": [...]}。
    """
    result = {"nodes": [], "cameras": [], "lights": []}
    path = os.path.join(export_dir or "", project.ART_DIR, f"{model_name}.glb")
    if not os.path.isfile(path):
        return result
    try:
        import json
        import struct

        with open(path, "rb") as handle:
            data = handle.read()
        offset = 12
        payload = None
        while offset < len(data):
            length, kind = struct.unpack_from("<II", data, offset)
            offset += 8
            if kind == 0x4E4F534A:      # "JSON"
                payload = json.loads(data[offset:offset + length].decode("utf-8"))
                break
            offset += length
        if payload is None:
            return result
    except (OSError, ValueError, struct.error):
        return result

    for node in payload.get("nodes", []):
        name = node.get("name", "")
        result["nodes"].append(name)
        if "camera" in node:
            result["cameras"].append(name)
        if node.get("extensions", {}).get("KHR_lights_punctual"):
            result["lights"].append(name)
    return result


def build_environment_nodes(scene, is_3d=True, skip=None, scene_name="World",
                            material_files=None):
    """决定相机和灯怎么处理。返回 (节点文本, 需要写的文件, 相机名)。

    节点文本里如果需要 ext_resource(id="env_script"),调用方要把它写出来。
    第二个返回值是 {相对路径: 内容} 形式的"需要额外写的文件"。

    ── 分两种情况 ──────────────────────────────────────────────────
    1. **glb 里已经有相机**(glTF 能带相机和灯,Blender 导出时会写进去,
       Godot 导入后自动生成 Camera3D / DirectionalLight3D):
       不再生成相机节点 —— 生成的话场景里会有两个相机,用户会发现
       "打开 Godot 多一个摄像头",而且分不清哪个是 Blender 的。
       只挂一个 Environment 脚本把主相机设成 current。

    2. **glb 里没有相机**(比如只导了网格):
       老老实实生成一个 Camera3D 和 DirectionalLight3D 节点,
       不然按 F5 是一片灰 —— 这个坑踩过。
    """
    if scene is None or not is_3d:
        return "", {}, ""

    skip = skip or {}
    glb_has_camera = bool(skip.get("cameras"))
    glb_has_light = bool(skip.get("lights"))

    parts = []
    files = {}

    # ---- 情况 1:相机来自 glb,只需要把它设成 current ----
    if glb_has_camera:
        active = scene.camera
        name = _sanitize_node_name(active.name) if active is not None else \
            _sanitize_node_name(skip["cameras"][0])
        # FOV 也要一起给:Godot 的 Camera3D.fov 是**垂直**视场角,
        # glTF 的 yfov 也是垂直的,理论上能对上;但用户可能在 Blender 里
        # 改过传感器比例,所以这里按 Blender 的当前值算一遍更稳。
        fov = 0.0
        if active is not None:
            try:
                # Blender 的 angle 是水平角,按传感器比例换算成垂直角
                horizontal = float(active.data.angle_x)
                render = getattr(scene, "render", None)
                width = float(getattr(render, "resolution_x", 1920) or 1920)
                height = float(getattr(render, "resolution_y", 1080) or 1080)
                if width > 0 and height > 0:
                    import math
                    fov = math.degrees(
                        2.0 * math.atan(math.tan(horizontal / 2.0)
                                        * height / width))
            except Exception:
                fov = 0.0

        # 太阳强度也要传:glTF 把 Blender 的太阳强度导成坎德拉级的大数字
        # (3.0 -> 2049),Godot 原样接收会把画面冲成纯白。
        # 见 ENVIRONMENT_SCRIPT 里的说明。
        sun = 0.0
        for obj in scene.objects:
            if obj.type == "LIGHT" and not obj.hide_get() and \
                    obj.data.type == "SUN":
                try:
                    sun = float(obj.data.energy)
                except (TypeError, ValueError):
                    sun = 0.0
                break

        # 用户在面板上调的灯光参数
        settings = getattr(scene, "gk_settings", None)
        energy = float(getattr(settings, "light_energy", 1.0) or 0.0)
        color = getattr(settings, "light_color", (1.0, 0.98, 0.94))
        try:
            lr, lg, lb = (float(color[0]), float(color[1]), float(color[2]))
        except (TypeError, ValueError, IndexError):
            lr, lg, lb = 1.0, 0.98, 0.94
        shadows = bool(getattr(settings, "light_shadows", True))
        azimuth = float(getattr(settings, "light_azimuth", 0.0) or 0.0)

        fields = dict(
            camera_name=name, fov=_fmt(fov), sun_strength=_fmt(sun),
            light_energy=_fmt(energy),
            lr=_fmt(lr), lg=_fmt(lg), lb=_fmt(lb),
            light_shadows="true" if shadows else "false",
            light_azimuth=_fmt(azimuth),
            materials=_material_table(material_files),
            lights=_light_table(scene),
        )
        parts.append(ENVIRONMENT_NODE.format(**fields))
        files[os.path.join(project.SCRIPTS_DIR, "gk_environment.gd")] = \
            ENVIRONMENT_SCRIPT.format(**fields)
        return "".join(parts), files, name

    # ---- 情况 2:glb 里没有,得自己补 ----
    for obj in scene.objects:
        if obj.type != "CAMERA" or obj.hide_get():
            continue
        position = _godot_position(obj, True)
        fov = 70.0
        try:
            fov = float(obj.data.angle_x) * _DEG
        except Exception:
            pass
        parts.append(ENVIRONMENT_CAMERA.format(
            name=_sanitize_node_name(obj.name),
            basis=_camera_basis_text(obj),
            cx=_fmt(position[0]), cy=_fmt(position[1]), cz=_fmt(position[2]),
            fov=fov))
        break       # 只补一个

    if not glb_has_light:
        for obj in scene.objects:
            if obj.type != "LIGHT" or obj.hide_get() or obj.data.type != "SUN":
                continue
            position = _godot_position(obj, True)
            energy = float(getattr(obj.data, "energy", 1.0))
            # Blender 的太阳能量 1.0 在 Godot 里偏暗,乘个系数让默认看起来正常
            parts.append(ENVIRONMENT_LIGHT.format(
                name=_sanitize_node_name(obj.name),
                basis=_light_basis_text(obj),
                lx=_fmt(position[0]), ly=_fmt(position[1]), lz=_fmt(position[2]),
                energy=max(0.2, min(energy * 1.2, 4.0))))
            break

    return "".join(parts), files, ""


def _light_table(scene):
    """把场景里的灯拼成脚本用的多行文本。

    约定:字段用 | 分隔,基向量的 9 个数内部用逗号。
    为什么不用 JSON:GDScript 解析 JSON 要额外代码和错误处理,
    而每行一盏灯本来就很直白。
    """
    rows = []
    for _obj, _settings, kind, info in collect_lights(scene):
        position = info["position"]
        color = info["color"]
        row = "|".join([
            kind,
            info["name"],
            _fmt(position[0]), _fmt(position[1]), _fmt(position[2]),
            info["basis"],
            _fmt(info["energy"]),
            _fmt(color[0]), _fmt(color[1]), _fmt(color[2]),
            "1" if info["shadows"] else "0",
            _fmt(info["radius"]),
            _fmt(info["angle"]),
        ])
        rows.append(row)
    return "\\n".join(rows)


def _material_table(material_files):
    """把 {节点名: 材质文件名} 拼成脚本里用的 "名字=路径" 多行文本。

    用换行分隔而不是 JSON:GDScript 里解析 JSON 要额外代码,
    而这个映射很简单,一行一个就够了。路径必须是 res:// 开头的正斜杠形式 ——
    Windows 的反斜杠 Godot 认不出来。
    """
    if not material_files:
        return ""
    lines = []
    for name in sorted(material_files):
        lines.append(f"{name}=res://{project.MATERIALS_DIR}/"
                     f"{material_files[name]}")
    # 脚本模板里的字面量是 \\n,这里给真正的换行,由 format 写进字符串
    return "\\n".join(lines)


def _sanitize_node_name(name):
    """Godot 节点名里不能有这些字符,换成下划线。

    点号尤其要紧:Godot 用 `.` 和 `:` 处理节点路径,
    名字里带点会让 `parent="A.B/C"` 这种路径解析出问题。
    """
    out = []
    for char in str(name):
        out.append("_" if char in '.:@/%"\\' else char)
    return "".join(out) or "Node"


# 弧度转角度(reduce 掉依赖 math 的一行常数)
_DEG = 57.29577951308232


def _light_basis_text(obj):
    """灯光的朝向。DirectionalLight3D 靠 -Z 指方向,和相机一样。

    只写位置不写朝向的话,太阳光一律从正上方照下来 ——
    在 Blender 里明明是斜着打的侧光,到 Godot 里就成了顶光,
    明暗完全对不上。所以朝向必须一起导出。
    """
    return _camera_basis_text(obj)


def _camera_basis_text(obj):
    """把 Blender 相机的朝向转成 Godot 的 Transform3D 基(9 个数)。

    ── 这里连着踩了两个坑,都记下来 ────────────────────────────────

    **坑一:.tscn 文本里 Transform3D 的 9 个数是"列优先"。**
    权威依据(用 Godot 自己验的,不是猜的):
        目标 basis.x=(1,2,3) y=(4,5,6) z=(7,8,9)
        官方 var_to_str 输出 = Transform3D(1, 4, 7, 2, 5, 8, 3, 6, 9, ...)
        再解析回来完全还原。
    规律:**三个基向量的第一个分量连续出现**(x.x, y.x, z.x),
    然后第二个分量、第三个分量。按行优先写等于把矩阵转置了 ——
    实测症状:相机朝上后方看,世界原点投到屏幕 y=1084(画面高 648),
    is_position_in_frustum=false,画面一片纯色。

    **坑二:相机看的是 -Z,不是 +Z。**
    直接抄旋转矩阵的列当基,会让 -Z 指向上后方。
    所以要用 right / up / back 三个方向来搭,其中 back = -(前方向)。

    坐标轴转换沿用 glTF 的 Y-up 约定:Godot(x, y, z) = Blender(x, z, -y)。
    """
    identity = ("1.000000, 0.000000, 0.000000, "
                "0.000000, 1.000000, 0.000000, "
                "0.000000, 0.000000, 1.000000")
    try:
        from mathutils import Vector

        basis = obj.matrix_world.to_3x3()
        # Blender 相机:局部 +X = 右,+Y = 上,局部 -Z = 前
        right = basis @ Vector((1.0, 0.0, 0.0))
        up = basis @ Vector((0.0, 1.0, 0.0))
        back = -(basis @ Vector((0.0, 0.0, -1.0)))   # 前方向取反

        def conv(v):
            """Blender 向量 -> Godot 向量(Z-up -> Y-up)。"""
            return (v.x, v.z, -v.y)

        rx, ry, rz = conv(right)
        ux, uy, uz = conv(up)
        bx, by, bz = conv(back)
        # **列优先**:x 轴三个分量、y 轴三个分量、z 轴三个分量
        # 即 x.x, y.x, z.x, x.y, y.y, z.y, x.z, y.z, z.z
        return (f"{_fmt(rx)}, {_fmt(ux)}, {_fmt(bx)}, "
                f"{_fmt(ry)}, {_fmt(uy)}, {_fmt(by)}, "
                f"{_fmt(rz)}, {_fmt(uz)}, {_fmt(bz)}")
    except Exception:
        return identity


def _godot_position(obj, is_3d=True):
    """把 Blender 物体的世界坐标转成 Godot 坐标。

    glTF 导出用 `export_yup=True`,做的是 **Z-up -> Y-up**:
        Blender(x, y, z)  ->  Godot(x, z, -y)

    这个转换必须在这里也做一遍 —— 否则碰撞体会全部堆在原点,
    看起来"有碰撞体"但完全对不上模型(实测踩过)。
    """
    if obj is None:
        return (0.0, 0.0, 0.0)
    try:
        from mathutils import Vector

        world = obj.matrix_world.translation
        x, y, z = float(world.x), float(world.y), float(world.z)
    except Exception:
        return (0.0, 0.0, 0.0)
    if not is_3d:
        # 2D:只取 x,y(Blender 的 Z 当成 2D 的 y 更符合直觉,
        # 因为在 2D 里用户通常把物体摆在 XY 平面上)
        return (x, y, 0.0)
    return (x, z, -y)


def guess_collision_shape(obj, is_3d=True):
    """按物体尺寸猜一个合适的碰撞形状。

    规则(面板上显示的和导出时用的是**同一份逻辑**):

      把三边从大到小排成 a >= b >= c,看**较小的两边 b/c** 的比值:

        b/c 很小(< 1.05)    -> 球      截面接近正方,两个小边都差不多
        c 很小(b/c 很大)    -> 盒子    **扁平**:有一个方向明显更薄
        b/c 居中(1.25~1.8) -> 胶囊    一个方向长,另两个方向中等且接近

    ── 为什么不是"最长/最短"比例 ──────────────────────────────────
    第一版用的是 longest/shortest,结果两个都错:
      * 圆柱(半径 = 高)的包围盒是**立方体**,比例 1.0,被判成球 ——
        球和圆柱在包围盒上确实分不出来,但那不该判成球
      * **压扁**的立方体比例高达 15,被当成"细长"判成胶囊 ——
        可它是扁的,明显该是盒子

    关键区别是**扁平**(一个方向薄)和**细长**(一个方向长)。
    只看最长/最短会把这两者混为一谈,所以现在看两个较小边的比例。
    """
    if obj is None:
        return "box"
    bounds = object_bounds([obj])
    if bounds is None:
        return "box"
    size = bounds["size"]
    if is_3d:
        dims = sorted((abs(size[0]), abs(size[1]), abs(size[2])), reverse=True)
    else:
        dims = sorted((abs(size[0]), abs(size[1])), reverse=True)
        dims.append(min(dims) * 0.5)      # 2D 里没有第三个轴,补一个"薄"的

    a, b, c = dims
    if c <= 1e-6:
        return "box"

    mid_ratio = b / c          # 两个较小边的比例
    long_ratio = a / b         # 最长边比中间边

    # 扁平:一个方向明显更薄 -> 盒子(墙、地板、平台)
    if mid_ratio > 1.8:
        return "box"
    # 细长:一个方向明显更长,另两个方向接近 -> 胶囊(人形、柱子)
    if long_ratio > 1.35 and mid_ratio <= 1.35:
        return "capsule"
    # 三边接近:包围盒分不出球和方盒。
    # 默认给球 —— 对于"看起来圆"的东西(道具、球体角色)球更贴合,
    # 而方块类物体用户通常会自己去面板上改成盒子。
    return "sphere"

def collision_preview_mesh(obj, is_3d=True, physics=None):
    """算出碰撞体的可视化线框数据(顶点 + 边)。

    返回 dict 或 None:
        {"verts": [(x,y,z), ...], "edges": [(i,j), ...]}

    为什么要这个:碰撞形状在 Blender 里**看不见** —— 用户只能靠"按尺寸会选:胶囊"
    这行字去猜它到底多大、贴不贴合。UPBGE 是直接把碰撞体画在视口里的,
    这里照做:导出前先给一个线框物体,所见即所得。

    坐标是**物体局部**的,调用方负责摆到正确位置。
    """
    if obj is None:
        return None
    bounds = object_bounds([obj])
    if bounds is None:
        return None

    shape = getattr(physics, "collision_shape", "auto") if physics else "auto"
    if shape == "none":
        return None
    if shape == "auto":
        shape = guess_collision_shape(obj, is_3d)

    override = None
    if physics is not None:
        raw = getattr(physics, "shape_size", None)
        if raw is not None and len(raw) == 3:
            override = (float(raw[0]), float(raw[1]), float(raw[2]))

    size = bounds["size"]
    if override is not None and shape != "auto":
        radius = max(override[0], 0.001)
        half_z = max(override[2], 0.001)
        height = max(override[1], 0.002)
    else:
        radius = max(size[0], size[2], 0.001) * 0.5
        half_z = max(size[2], 0.001) * 0.5
        height = max(size[1], 0.002)

    if shape == "box":
        if override is not None:
            hx, hy, hz = (max(override[0], 0.001) * 0.5,
                          max(override[1], 0.002) * 0.5,
                          max(override[2], 0.001) * 0.5)
        else:
            hx = max(size[0], 0.001) * 0.5
            hy = max(size[1], 0.002) * 0.5
            hz = max(size[2], 0.001) * 0.5
        verts = [(-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
                 (-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz)]
        edges = [(0, 1), (1, 2), (2, 3), (3, 0),
                 (4, 5), (5, 6), (6, 7), (7, 4),
                 (0, 4), (1, 5), (2, 6), (3, 7)]
        return {"verts": verts, "edges": edges}

    if shape == "sphere":
        return _sphere_wire(radius)

    if shape == "capsule":
        # 胶囊 = 上下半球 + 两条直边。用线框近似,段数够看清就行。
        return _capsule_wire(radius, max(height, radius * 2.0))

    if shape == "cylinder":
        return _cylinder_wire(radius, max(height, 0.002))

    return None


def _sphere_wire(radius, segments=16, rings=4):
    """球的线框:经线 + 纬线。

    用标准的球坐标:
        x = r * sin(phi) * cos(theta)
        y = r * sin(phi) * sin(theta)
        z = r * cos(phi)
    phi 是极角(0..pi),theta 是方位角(0..2pi)。
    """
    import math

    verts = []
    edges = []

    # 经线:固定 theta,扫 phi
    for i in range(4):
        theta = math.pi * i / 4.0
        base = len(verts)
        for j in range(segments + 1):
            phi = math.pi * j / segments
            verts.append((radius * math.sin(phi) * math.cos(theta),
                          radius * math.sin(phi) * math.sin(theta),
                          radius * math.cos(phi)))
        for j in range(segments):
            edges.append((base + j, base + j + 1))

    # 纬线:固定 phi,扫 theta
    for k in range(1, rings + 1):
        phi = math.pi * k / (rings + 1)
        r = radius * math.sin(phi)
        z = radius * math.cos(phi)
        base = len(verts)
        for j in range(segments):
            theta = 2.0 * math.pi * j / segments
            verts.append((r * math.cos(theta), r * math.sin(theta), z))
        for j in range(segments):
            edges.append((base + j, base + (j + 1) % segments))

    return {"verts": verts, "edges": edges}


def _capsule_wire(radius, height, segments=16):
    """胶囊线框:两圈 + 四条竖边 + 半球弧。"""
    import math

    half = max(height * 0.5 - radius, 0.0)
    verts = []
    edges = []
    for z in (half, -half):
        base = len(verts)
        for j in range(segments):
            theta = 2.0 * math.pi * j / segments
            verts.append((radius * math.cos(theta), radius * math.sin(theta), z))
        for j in range(segments):
            edges.append((base + j, base + (j + 1) % segments))
    top = len(verts) - 2 * segments
    bottom = len(verts) - segments
    for j in range(0, segments, max(1, segments // 4)):
        edges.append((top + j, bottom + j))
    # 上下极点
    apex_top = len(verts)
    verts.append((0.0, 0.0, half + radius))
    apex_bottom = len(verts)
    verts.append((0.0, 0.0, -half - radius))
    for j in range(0, segments, max(1, segments // 4)):
        edges.append((top + j, apex_top))
        edges.append((bottom + j, apex_bottom))
    return {"verts": verts, "edges": edges}


def _cylinder_wire(radius, height, segments=16):
    import math

    half = height * 0.5
    verts = []
    edges = []
    for z in (half, -half):
        base = len(verts)
        for j in range(segments):
            theta = 2.0 * math.pi * j / segments
            verts.append((radius * math.cos(theta), radius * math.sin(theta), z))
        for j in range(segments):
            edges.append((base + j, base + (j + 1) % segments))
    top = len(verts) - 2 * segments
    bottom = len(verts) - segments
    for j in range(0, segments, max(1, segments // 4)):
        edges.append((top + j, bottom + j))
    return {"verts": verts, "edges": edges}


def _fmt(value):
    """Godot 的浮点写法。留 6 位小数,避免科学计数法。"""
    return f"{float(value):.6f}"


# 3D 碰撞形状的 sub_resource 模板
SHAPE_TEMPLATES_3D = {
    "box": ('[sub_resource type="BoxShape3D" id="shape"]\n'
            "size = Vector3({x}, {y}, {z})"),
    "sphere": ('[sub_resource type="SphereShape3D" id="shape"]\n'
               "radius = {r}"),
    "capsule": ('[sub_resource type="CapsuleShape3D" id="shape"]\n'
                "radius = {r}\nheight = {h}"),
    "cylinder": ('[sub_resource type="CylinderShape3D" id="shape"]\n'
                 "radius = {r}\nheight = {h}"),
}

SHAPE_TEMPLATES_2D = {
    "box": ('[sub_resource type="RectangleShape2D" id="shape"]\n'
            "size = Vector2({x}, {y})"),
    "sphere": ('[sub_resource type="CircleShape2D" id="shape"]\n'
               "radius = {r}"),
    "capsule": ('[sub_resource type="CapsuleShape2D" id="shape"]\n'
                "radius = {r}\nheight = {h}"),
    "cylinder": ('[sub_resource type="CircleShape2D" id="shape"]\n'
                 "radius = {r}"),
}


def build_collision(obj, is_3d=True, physics=None):
    """给一个物体算出碰撞体配置。

    返回 dict 或 None(不需要碰撞时):
        {"shape": "capsule", "sub_resource": "...", "node": "...", "offset": (x,y,z)}
    `node` 是挂在物体下面的 CollisionShape 节点文本。
    """
    if obj is None:
        return None

    shape = "auto"
    layer = "1"
    mask = "1"
    is_trigger = False
    override_size = None

    if physics is not None:
        shape = getattr(physics, "collision_shape", "auto")
        layer = getattr(physics, "collision_layer", "1")
        mask = getattr(physics, "collision_mask", "1")
        is_trigger = bool(getattr(physics, "is_trigger", False))
        size = getattr(physics, "shape_size", None)
        if size is not None and len(size) == 3:
            override_size = (float(size[0]), float(size[1]), float(size[2]))

    if shape == "none":
        return None
    if shape == "auto":
        shape = guess_collision_shape(obj, is_3d)

    bounds = object_bounds([obj])
    if bounds is None:
        return None
    size = bounds["size"]

    # 形状参数
    if is_3d:
        if override_size is not None:
            radius = max(override_size[0], 0.001)
            height = max(override_size[1], 0.002)
            half = (override_size[0], override_size[1] * 0.5, override_size[2])
        else:
            radius = max(size[0], size[2], 0.001) * 0.5
            height = max(size[1], 0.002)
            half = (size[0] * 0.5, size[1] * 0.5, size[2] * 0.5)
        params = {
            "x": _fmt(half[0] * 2.0), "y": _fmt(half[1] * 2.0),
            "z": _fmt(half[2] * 2.0),
            "r": _fmt(radius), "h": _fmt(max(height, radius * 2.0)),
        }
        template = SHAPE_TEMPLATES_3D.get(shape, SHAPE_TEMPLATES_3D["box"])
        node_type = "CollisionShape3D"
        offset = (0.0, 0.0, 0.0)
    else:
        if override_size is not None:
            radius = max(override_size[0], 0.001)
            height = max(override_size[1], 0.002)
        else:
            radius = max(size[0], 0.001) * 0.5
            height = max(size[1], 0.002)
        params = {
            "x": _fmt(max(size[0], 0.002)), "y": _fmt(max(size[1], 0.002)),
            "z": "0.0",
            "r": _fmt(radius), "h": _fmt(max(height, radius * 2.0)),
        }
        template = SHAPE_TEMPLATES_2D.get(shape, SHAPE_TEMPLATES_2D["box"])
        node_type = "CollisionShape2D"
        offset = (0.0, 0.0, 0.0)

    body_type = "StaticBody3D"
    if physics is not None:
        body_type = getattr(physics, "body_type", "StaticBody3D")
    if is_trigger or "Area" in body_type:
        node_type = "CollisionShape3D" if is_3d else "CollisionShape2D"

    node_lines = [f'[node name="Collision" type="{node_type}" parent="."]',
                  'shape = SubResource("shape")']
    if offset != (0.0, 0.0, 0.0):
        node_lines.append(f"position = Vector3({_fmt(offset[0])}, "
                          f"{_fmt(offset[1])}, {_fmt(offset[2])})")
    if layer != "1" or mask != "1":
        node_lines.append(f"collision_layer = {int(layer)}")
        node_lines.append(f"collision_mask = {int(mask)}")

    return {
        "shape": shape,
        "sub_resource": template.format(**params),
        "node": "\n".join(node_lines),
        "layer": layer,
        "mask": mask,
        "is_trigger": is_trigger,
    }


def collect_physics(scene):
    """收集场景里所有物体的物理设置。

    返回 [(物体, 设置对象, 是否启用)] —— 顺序跟场景一致,生成结果稳定。
    不导入 bpy:scene 由调用方传进来,这样离线测试也能跑。
    """
    if scene is None:
        return []
    out = []
    for obj in scene.objects:
        physics = getattr(obj, "gk_physics", None)
        enabled = bool(getattr(physics, "enabled", True)) if physics else True
        out.append((obj, physics, enabled))
    return out


def scene_materials(scene, enabled_only=True):
    """收集"对象名 -> 材质文件"的映射,给 write_world_scene 做材质覆盖用。

    返回 {对象名: (材质资源名, materials/ 下的文件名)}。

    为什么需要:glTF **不携带 NPR 外观**。卡通着色靠色阶切分、边缘光、
    面部 SDF,glTF 的 PBR 材质表达不了,所以 .glb 里全是素白的
    StandardMaterial3D。我们给每个 Blender 材质生成的 .tres 一直没被引用。

    有了这个映射,包装场景就能给每个对象加一条 material_override,
    直接指向 .tres —— glb 负责几何,tres 负责外观。
    """
    out = {}
    if scene is None:
        return out
    for obj in scene.objects:
        if getattr(obj, "type", "") != "MESH":
            continue
        if obj.get(PREVIEW_MARK):
            continue
        if enabled_only:
            physics = getattr(obj, "gk_physics", None)
            if physics is not None and not getattr(physics, "enabled", True):
                continue
        material = first_real_material(obj)
        if material is None:
            continue
        file_name = safe_name(material.name, "material") + ".tres"
        out[obj.name] = (material.name, file_name)
    return out


def first_real_material(obj):
    """取物体的第一个**正经**材质,跳过工具生成的预览材质。

    为什么要跳:『显示描边预览』会往 obj.data.materials 里 append 一个
    叫 __GK描边预览材质__ 的纯色材质。如果不管它,导出时它会被当成
    物体的材质导出去 —— 用户会看到自己的模型在 Godot 里变成一个纯黑壳。
    """
    for material in (getattr(obj.data, "materials", None) or ()):
        if material is None:
            continue
        if material.name.startswith(TOOL_MATERIAL_PREFIX):
            continue
        return material
    return None


def _base_color_texture(material):
    """从 Blender 材质里找 Base Color 贴图，返回图片名(导出后 Godot 里的文件名)。"""
    if material is None or not material.use_nodes:
        return None
    for node in material.node_tree.nodes:
        if node.type != "BSDF_PRINCIPLED":
            continue
        socket = node.inputs.get("Base Color")
        if socket is None or not socket.is_linked:
            continue
        source = socket.links[0].from_node
        if source.type == "TEX_IMAGE" and source.image is not None:
            return source.image.name
    return None


def _base_color_rgb(material):
    """取材质的基础色，用作卡通材质的主色。"""
    fallback = (0.85, 0.82, 0.88)
    if material is None or not material.use_nodes:
        return fallback
    for node in material.node_tree.nodes:
        if node.type != "BSDF_PRINCIPLED":
            continue
        socket = node.inputs.get("Base Color")
        if socket is None:
            continue
        if socket.is_linked:
            continue
        value = socket.default_value
        return (float(value[0]), float(value[1]), float(value[2]))
    return fallback


def write_npr_material(export_dir, material, shader_res_dir="shaders"):
    """把 Blender 里的 NPR 预览材质导出成 Godot 的 .tres。

    这是"在 Blender 里调参"能成立的关键一步:参数存在材质自定义属性上,
    这里读出来直接写成 Godot 的 shader_parameter,两边不会各调一遍。

    返回 (文件路径, 参数个数);材质不是 NPR 材质时返回 (None, 0)。
    """
    # npr_preview 在模块级导入。
    # 注意:不能在函数内部写 from . import npr_preview —— 在 Blender 扩展
    # 环境里,函数局部的相对导入会因为模块路径解析方式不同而报
    # "'bl_ext' is not a package"。模块级导入没有这个问题。
    params = npr_preview.read_params(material)
    if not params:
        return None, 0

    name = safe_name(material.name, "material")
    texture = _base_color_texture(material)

    textures_block = ""
    albedo_ref = "null"
    steps = 2
    if texture:
        tex_name = safe_name(texture, "texture") + ".png"
        textures_block = (
            f'[ext_resource type="Texture2D" path="res://{project.ART_DIR}/{tex_name}" '
            f'id="2_albedo"]\n'
        )
        albedo_ref = 'ExtResource("2_albedo")'
        steps = 3

    lines = [
        f'[gd_resource type="ShaderMaterial" load_steps={steps} format=3]',
        "",
        f'[ext_resource type="Shader" path="res://{shader_res_dir}/gk_toon.gdshader" '
        f'id="1_shader"]',
    ]
    if textures_block:
        lines.append(textures_block.rstrip("\n"))
    lines.append("")
    lines.append("[resource]")
    lines.append('shader = ExtResource("1_shader")')
    lines.append(f"shader_parameter/albedo_texture = {albedo_ref}")
    # 必须显式写开关:hint_default_white 让未指定贴图时 texture() 恒返回白色,
    # 运行时区分不出"没贴图"和"贴图是白的"。
    lines.append(f"shader_parameter/use_albedo_texture = "
                 f"{1.0 if texture else 0.0:.1f}")

    for uniform, value in params.items():
        if isinstance(value, (tuple, list)):
            r, g, b = float(value[0]), float(value[1]), float(value[2])
            lines.append(
                f"shader_parameter/{uniform} = Color({r:.6f}, {g:.6f}, {b:.6f}, 1)"
            )
        else:
            lines.append(f"shader_parameter/{uniform} = {float(value):.6f}")

    path = os.path.join(export_dir, "materials", f"{name}.tres")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines) + "\n")
    return path, len(params)


def write_materials(export_dir, objects, shader_res_dir="shaders"):
    """给每个 Blender 材质生成一份 Godot 卡通材质。返回 [(材质名, 文件路径, 有无贴图)]。

    objects 传 None 表示"整个场景里所有网格的材质" —— 整场景导出时用这个,
    因为场景里每个对象都需要自己的 .tres 才能显示成卡通。
    """
    if objects is None:
        import bpy

        scene = getattr(bpy.context, "scene", None)
        objects = [obj for obj in (scene.objects if scene else [])
                   if getattr(obj, "type", "") == "MESH"
                   and not obj.get(PREVIEW_MARK)]

    written = []
    seen = set()
    for obj in objects:
        for slot in getattr(obj, "material_slots", ()):
            material = slot.material
            if material is None or material.name in seen:
                continue
            # 跳过工具生成的辅助材质(描边预览的纯色壳)。
            # 不跳的话它会变成一条 .tres,用户可能在 Godot 里选中它,
            # 把模型改成纯黑。
            if material.name.startswith(TOOL_MATERIAL_PREFIX):
                continue
            seen.add(material.name)
            name = safe_name(material.name, "material")
            rgb = _base_color_rgb(material)
            texture = _base_color_texture(material)

            textures_block = ""
            albedo_ref = "null"
            steps = 2
            if texture:
                tex_name = safe_name(texture, "texture") + ".png"
                textures_block = (
                    f'[ext_resource type="Texture2D" '
                    f'path="res://{project.ART_DIR}/{tex_name}" id="2_albedo"]\n'
                )
                albedo_ref = 'ExtResource("2_albedo")'
                steps = 3

            # ---- 描边 ----
            # 每条材质都可以有自己的描边参数(存在材质的自定义属性上),
            # 关掉时就不生成那个 pass —— 省一次绘制。
            outline = _outline_settings(material)
            if outline["width"] > 0.0001:
                outline_ext = OUTLINE_EXT_RESOURCE.format(
                    outline_shader=f"res://{shader_res_dir}/gk_outline.gdshader")
                outline_sub = OUTLINE_SUB_RESOURCE.format(**outline)
                outline_pass = OUTLINE_NEXT_PASS
                steps += 2      # 一个 ext_resource + 一个 sub_resource
            else:
                outline_ext = ""
                outline_sub = ""
                outline_pass = ""

            text = TOON_MATERIAL_TEMPLATE.format(
                steps=steps,
                shader_path=f"res://{shader_res_dir}/gk_toon.gdshader",
                textures=textures_block,
                outline_ext=outline_ext,
                outline_sub=outline_sub,
                outline_pass=outline_pass,
                r=rgb[0], g=rgb[1], b=rgb[2],
                albedo_ref=albedo_ref,
                use_texture=1.0 if texture else 0.0,
                outline_param="",
            )
            path = os.path.join(export_dir, project.MATERIALS_DIR, f"{name}.tres")
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(text)
            written.append((material.name, path, bool(texture)))
    return written


def _outline_settings(material):
    """读材质上的描边参数。没有就用一组合理的默认值(默认关)。

    参数存在材质的自定义属性上,和 NPR 预览面板共用 ——
    这样在 Blender 里调的描边粗细,导出时就照搬过去。
    """
    def num(key, fallback):
        value = material.get(key) if material else None
        try:
            return float(value)
        except (TypeError, ValueError):
            return float(fallback)

    color = material.get("outline_color") if material else None
    try:
        cr, cg, cb = (float(color[0]), float(color[1]), float(color[2]))
    except (TypeError, ValueError, IndexError):
        cr, cg, cb = 0.05, 0.04, 0.09

    return {
        "width": num("outline_width", 0.0),
        "cr": cr, "cg": cg, "cb": cb,
        "screen_constant": num("outline_screen_constant", 0.0),
        "boost": num("outline_silhouette_boost", 0.0),
        "jitter": num("outline_jitter", 0.0),
        "jitter_fps": num("outline_jitter_fps", 10.0),
        "jitter_width": num("outline_jitter_width", 0.25),
        "jitter_offset": num("outline_jitter_offset", 0.004),
    }


def export_textures(export_dir, materials):
    """把材质用到的贴图导出成 PNG 到 art/。

    返回 [(图片名, 路径)]。

    ── 为什么必须有这一步 ──────────────────────────────────────────
    生成的 .tres 里有这么一行:
        [ext_resource type="Texture2D" path="res://art/xxx.png" ...]
    如果那个 PNG 不存在,Godot 加载 .tres 会失败,进而**整个场景实例化失败**
    ——表现是打开游戏一片空白/一片灰,而日志里只有一行
    "Failed loading resource"。这个坑实测踩过,而且是"卡通材质显示不出来"
    的直接原因:普通图片材质直接挂在模型上、不经过 .tres,所以看不出问题。

    glTF 会把贴图**内嵌**进 .glb,但那只对 glb 自己的材质有效;
    我们的 .tres 是独立文件,必须自己把 PNG 落盘。
    """
    import bpy

    out = []
    seen = set()
    target_dir = os.path.join(export_dir, project.ART_DIR)
    os.makedirs(target_dir, exist_ok=True)

    for material in materials or ():
        if material is None:
            continue
        for name in _material_image_names(material):
            if name in seen:
                continue
            seen.add(name)
            image = bpy.data.images.get(name)
            if image is None or image.size[0] == 0:
                continue
            file_name = safe_name(name, "texture") + ".png"
            path = os.path.join(target_dir, file_name)
            try:
                _save_image(image, path)
            except Exception as exc:
                gk_log.warn(f"贴图 {name} 导出失败: {exc}")
                continue
            out.append((name, path))
    return out


def _save_image(image, path):
    """把 Blender 图像存成 PNG。

    优先用 save_render —— 它对**程序生成**的图像也有效
    (bpy.data.images.new() 造的图没有磁盘路径,save() 会失败)。
    失败则退回 save()。
    """
    import bpy

    try:
        image.save_render(path)
        return
    except Exception:
        pass
    scene = getattr(bpy.context, "scene", None)
    settings = scene.render.image_settings if scene is not None else None
    old_format = getattr(settings, "file_format", None)
    if settings is not None:
        settings.file_format = "PNG"
    try:
        image.filepath_raw = path
        image.file_format = "PNG"
        image.save()
    finally:
        if settings is not None and old_format is not None:
            settings.file_format = old_format


def _material_image_names(material):
    """列出材质里用到的所有图像名(包括非 Base Color 的,比如 SDF)。"""
    names = []
    if material is None or not getattr(material, "use_nodes", False):
        return names
    tree = getattr(material, "node_tree", None)
    if tree is None:
        return names
    for node in tree.nodes:
        image = getattr(node, "image", None)
        if image is not None and getattr(image, "name", ""):
            names.append(image.name)
    return names


def glb_scene_nodes(export_dir, model_name="World"):
    """解析 .glb,返回可以直接建成 Godot 节点的信息。

    返回 {"meshes": {物体名: 网格资源名}, "cameras": [...], "lights": [...],
          "nodes": [...]}。

    ── 为什么要解析 glb 而不直接 instance 它 ────────────────────────
    包装场景原本是 `[node name="World" instance=ExtResource("1_world")]`,
    然后另外声明节点给实例内部的子节点加 material_override。
    **这条路在 Godot 里走不通**:

        WARNING: Parent path './World' for node 'Ball' has vanished
                 when instantiating: 'res://scenes/World.tscn'.

    glb 实例的内部子节点不能被外部节点覆盖 —— 材质覆盖**从来没生效过**,
    用户在 Godot 里看到的永远是白模。加 editable_children = true 也没用
    (实测过)。

    所以改成:把 glb 里的每个对象展开成一个 MeshInstance3D 节点,
    网格用 ExtResource 指向 glb 里的 mesh 资源(形如 "1_world/BallMesh"),
    材质直接写在 mesh 上。这样**没有任何覆盖**,Godot 不会抱怨,
    而且 .tscn 里就能看到完整的对象树。
    """
    result = {"meshes": {}, "cameras": [], "lights": [], "nodes": [],
              "materials": {}}
    path = os.path.join(export_dir or "", project.ART_DIR, f"{model_name}.glb")
    if not os.path.isfile(path):
        return result
    try:
        import json
        import struct

        with open(path, "rb") as handle:
            data = handle.read()
        offset = 12
        payload = None
        while offset < len(data):
            length, kind = struct.unpack_from("<II", data, offset)
            offset += 8
            if kind == 0x4E4F534A:      # "JSON"
                payload = json.loads(data[offset:offset + length].decode("utf-8"))
                break
            offset += length
        if payload is None:
            return result
    except (OSError, ValueError, struct.error):
        return result

    meshes = payload.get("meshes", [])
    materials = payload.get("materials", [])

    for index, mesh in enumerate(meshes):
        # glTF 的网格名 = Blender 的 mesh data 名,不一定等于对象名,
        # 所以按**节点**去找更靠得住 —— 下面遍历节点时再填。
        result["materials"][index] = mesh.get("name", f"Mesh{index}")

    for node in payload.get("nodes", []):
        name = node.get("name", "")
        if "mesh" in node:
            mesh_index = node["mesh"]
            mesh_name = (meshes[mesh_index].get("name", "") if
                         mesh_index < len(meshes) else "")
            primitives = (meshes[mesh_index].get("primitives", [])
                          if mesh_index < len(meshes) else [])
            material_index = None
            if primitives:
                material_index = primitives[0].get("material")
            material_name = ""
            if material_index is not None and material_index < len(materials):
                material_name = materials[material_index].get("name", "")
            result["meshes"][name] = {
                "mesh_resource": mesh_name or name,
                "primitives": len(primitives),
                "material": material_name,
            }
        if "camera" in node:
            result["cameras"].append(name)
        if node.get("extensions", {}).get("KHR_lights_punctual"):
            result["lights"].append(name)
        result["nodes"].append(name)
    return result


def _glb_node_matrix(payload, node):
    """把 glTF 节点的 TRS 转成 Godot 的 Transform3D 文本。

    glTF 用 TRS(translation / rotation 四元数 / scale)**列优先**矩阵,
    Godot 的 Transform3D 也是列优先 —— 所以顺序一致,可以直接展开。
    但**有旋转/缩放时必须算矩阵**,不能只写平移:
    相机和太阳的朝向全靠这个,只写平移它们就会一起朝上。
    """
    translation = node.get("translation", [0.0, 0.0, 0.0])
    rotation = node.get("rotation", [0.0, 0.0, 0.0, 1.0])     # x, y, z, w
    scale = node.get("scale", [1.0, 1.0, 1.0])

    x, y, z, w = (float(rotation[0]), float(rotation[1]),
                  float(rotation[2]), float(rotation[3]))
    sx, sy, sz = (float(scale[0]), float(scale[1]), float(scale[2]))
    # 四元数 -> 3x3 旋转矩阵(标准公式)
    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    wx, wy, wz = w * x, w * y, w * z
    m = [
        [1 - 2 * (yy + zz), 2 * (xy - wz), 2 * (xz + wy)],
        [2 * (xy + wz), 1 - 2 * (xx + zz), 2 * (yz - wx)],
        [2 * (xz - wy), 2 * (yz + wx), 1 - 2 * (xx + yy)],
    ]
    # 乘上缩放(列缩放)
    for row in range(3):
        m[row][0] *= sx
        m[row][1] *= sy
        m[row][2] *= sz

    # Godot 的 Transform3D 文本里,9 个数依次是 **X 轴、Y 轴、Z 轴**三个向量,
    # 然后才是原点。
    #
    # ── 这个顺序我搞错过,把判别方法记下来 ──────────────────────────
    # 错误经历:拿一个"看起来足够随机"的矩阵 (1,2,3,4,5,6,7,8,9) 去试,
    # 结论是"列优先",于是照此生成 —— 结果相机方向整体反了。
    #
    # **那个测试矩阵没有区分力**:在这个矩阵上,按行读和按列读得到的
    # "前方向"符号恰好一样,所以它证明不了任何事。
    #
    # 可靠的判别方法:用一个真实的不对称矩阵(相机旋转)去比 ——
    # 两种读法给出的前方向符号相反,拿 Godot 实测值一对就知道是哪种。
    values = [m[0][0], m[1][0], m[2][0],
              m[0][1], m[1][1], m[2][1],
              m[0][2], m[1][2], m[2][2],
              float(translation[0]), float(translation[1]), float(translation[2])]
    return ", ".join(_fmt(v) for v in values)


def build_model_nodes(export_dir, model_name, node_names, materials_map,
                      resource_id="1_world", indent=""):
    """把 glb 里的对象展开成 Godot 的 MeshInstance3D 节点文本。

    返回 (节点文本, 用到的网格资源名列表)。

    为什么要展开而不是 instance glb:见 glb_scene_nodes 的说明 ——
    glb 实例的内部子节点没法从外部覆盖材质,加 editable_children 也没用。
    展开之后材质直接挂在 mesh 上,不需要任何覆盖。
    """
    import json
    import struct

    path = os.path.join(export_dir or "", project.ART_DIR, f"{model_name}.glb")
    if not os.path.isfile(path):
        return "", []
    try:
        with open(path, "rb") as handle:
            data = handle.read()
        offset = 12
        payload = None
        while offset < len(data):
            length, kind = struct.unpack_from("<II", data, offset)
            offset += 8
            if kind == 0x4E4F534A:
                payload = json.loads(data[offset:offset + length].decode("utf-8"))
                break
            offset += length
        if payload is None:
            return "", []
    except (OSError, ValueError, struct.error):
        return "", []

    meshes = payload.get("meshes", [])
    lines = []
    used = []
    wanted = set(node_names or ())
    for node in payload.get("nodes", []):
        name = node.get("name", "")
        if "mesh" not in node or (wanted and name not in wanted):
            continue
        mesh_index = node["mesh"]
        if mesh_index >= len(meshes):
            continue
        mesh_resource = meshes[mesh_index].get("name", "") or name
        used.append(mesh_resource)
        lines.append(f'{indent}[node name="{_sanitize_node_name(name)}" '
                     f'type="MeshInstance3D" parent="."]')
        lines.append(f'{indent}transform = Transform3D('
                     f'{_glb_node_matrix(payload, node)})')
        lines.append(f'{indent}mesh = ExtResource("{resource_id}/{mesh_resource}")')
        material_file = (materials_map or {}).get(name, (None, None))[1]
        if material_file:
            lines.append(f'{indent}material_override = '
                         f'ExtResource("res://{project.MATERIALS_DIR}/'
                         f'{material_file}")')
        lines.append("")
    return "\n".join(lines), used


def collect_lights(scene):
    """收集要导出到 Godot 的灯。返回 [(物体, 设置, Godot 灯型, 参数字典)]。

    ── 为什么不能让 glTF 自己带灯 ──────────────────────────────────
    glTF 的 KHR_lights_punctual **只有平行光**能用得好:
      * 方向光 -> DirectionalLight3D,位置和朝向都对
      * 点光   -> Godot 会建成 OmniLight3D,但**能量单位对不上**
                 (glTF 用坎德拉,Godot 用流明),亮度差几十倍
      * 聚光   -> 同理,而且锥角也会丢
    Blender 的**面光**在 glTF 里根本没有对应物,直接丢失。

    所以除了平行光之外,其余的由这里生成**真正的 Godot 节点**,
    并把 glb 带进来的那些灯关掉(见环境脚本),避免两套灯叠加。

    ── 能量换算(各自单位不同,不能照搬)──────────────────────────
    Godot 的三种灯能量单位不一样:
        DirectionalLight3D  勒克斯(lux)  —— 不衰减
        OmniLight3D         流明(lumen)  —— 随距离衰减
        SpotLight3D         流明(lumen)  —— 随距离衰减
    Blender 的瓦数(W)是辐射功率,和上面三个都不是一回事。
    实测标定:Blender 日光 strength 3.0 导出后 Godot 显示 26.09,
    所以平行光用 strength/8.7;点光/聚光按灯的实际功率折算。
    """
    from . import properties as props

    out = []
    if scene is None:
        return out
    for obj in scene.objects:
        if getattr(obj, "type", "") != "LIGHT":
            continue
        settings = getattr(obj, "gk_light", None)
        if settings is not None and not getattr(settings, "enabled", True):
            continue
        if obj.hide_get():
            continue

        data = obj.data
        blender_type = getattr(data, "type", "POINT")
        godot_type = None
        if settings is not None:
            godot_type = getattr(settings, "godot_type", None)
        if not godot_type or godot_type == "skip":
            godot_type = props.BLENDER_TO_GODOT_LIGHT.get(blender_type, "omni")
        if godot_type == "skip":
            continue

        energy = float(getattr(data, "energy", 1.0) or 1.0)
        if godot_type == "directional":
            # 平行光:Godot 的 light_energy 就是"相对太阳亮度",1.0 是默认
            value = energy / 8.7
        else:
            # 点光 / 聚光:Godot 用流明。Blender 的瓦数按 1W ≈ 683lm 折算,
            # 但要再压一档 —— 实测直接按 683 换算会亮到发白。
            value = energy * 683.0 / 700.0
        if settings is not None:
            value *= max(0.0, float(getattr(settings, "energy_scale", 1.0) or 1.0))

        color = (1.0, 1.0, 1.0)
        if settings is not None:
            custom = getattr(settings, "color", None)
            try:
                if custom is not None and not all(
                        abs(float(c) - 1.0) < 1e-4 for c in custom):
                    color = (float(custom[0]), float(custom[1]), float(custom[2]))
                else:
                    color = tuple(float(c) for c in data.color[:3])
            except (TypeError, ValueError, IndexError):
                color = tuple(float(c) for c in data.color[:3])
        else:
            color = tuple(float(c) for c in data.color[:3])

        shadows = bool(getattr(settings, "shadows", True)) if settings else True
        position = _godot_position(obj, True)
        basis = _camera_basis_text(obj)

        # 作用范围:方向光不需要;点光/聚光按 Blender 灯的尺寸放大
        radius = 0.0
        if godot_type in ("omni", "spot", "area_omni"):
            custom_range = float(getattr(settings, "range_scale", 0.0) or 0.0) \
                if settings else 0.0
            if custom_range > 0:
                radius = custom_range
            elif blender_type == "AREA":
                # 面光:按矩形对角线放大,让点光"罩住"原来的面积
                size_x = float(getattr(data, "size", 1.0) or 1.0)
                size_y = float(getattr(data, "size_y", size_x) or size_x)
                radius = max(2.0, (size_x ** 2 + size_y ** 2) ** 0.5 * 2.0)
            else:
                radius = max(2.0, float(getattr(data, "shadow_soft_size", 0.25) or 0.25)
                             * 20.0)

        angle = 0.0
        if godot_type == "spot":
            try:
                angle = float(getattr(data, "spot_size", 0.785))
            except (TypeError, ValueError):
                angle = 0.785

        out.append((obj, settings, godot_type, {
            "name": _sanitize_node_name(obj.name),
            "blender_type": blender_type,
            "position": position,
            "basis": basis,
            "energy": value,
            "color": color,
            "shadows": shadows,
            "radius": radius,
            "angle": angle,
        }))
    return out


def export_assets_pipeline(scene, directory, dimension="3", script_name=None):
    """完整的资产导出流程:整场景 glb -> 材质 -> 包装场景 -> 角色场景。

    返回一个结果字典,不抛异常(出错时把错误放进 "error"),
    这样调用方(比如"运行前自动导出")可以简单地警告一下就继续。

    ── 为什么抽成独立函数 ──────────────────────────────────────────
    这段流程以前只存在于 bpy.ops.gk.export_assets 的 execute 里。
    但"直接运行游戏时自动导出"也需要它 —— 在算子里再调另一个算子会卷进
    Blender 的操作符上下文约定,出问题时错误信息很难懂。
    这里的每一步本来就是纯函数,抽出来直接调更清楚。

    ── 顺序很重要 ──────────────────────────────────────────────────
    材质**必须在包装场景之前**生成:包装场景要用 material_override
    引用 materials/*.tres,引用不存在的文件 Godot 会报错。

    模型用整场景那份:只 instance 角色的话,按 F5 只能看到角色一个人
    悬在空中,地面和别的道具都不见了(实测踩过)。
    """
    import bpy

    result = {"written": [], "warnings": [], "error": None,
              "bodies": 0, "materials": 0, "textures": 0,
              "cameras": 0, "lights": 0}
    if scene is None or not directory:
        result["error"] = "没有场景或没有项目目录"
        return result

    is_3d = str(dimension) != "2"

    # ---- 1) 整场景 glb ----
    world_path, world_ok, world_message = export_scene_glb(directory, "World",
                                                           scene=scene)
    if world_ok:
        result["written"].append(world_path)
    else:
        result["warnings"].append(f"整场景导出失败: {world_message}")

    # ---- 2) 材质(必须在包装场景之前)----
    #
    # 贴图必须在材质**之前或同时**落盘:.tres 里引用
    # `res://art/xxx.png`,文件不存在的话 Godot 加载 .tres 会失败,
    # 进而整个场景实例化失败 —— 表现是打开一片空白,日志里只有一行
    # "Failed loading resource"。这是"卡通材质显示不出来"的直接原因。
    materials_map = scene_materials(scene)
    try:
        materials = write_materials(directory, None)
        result["written"].extend(item[1] for item in materials)
        result["written"].extend(copy_shaders(directory))
        result["materials"] = len(materials)
        # 贴图要跟着材质一起落盘。scene_materials 的键值是
        # (材质资源名, 文件名),这里用资源名去 bpy.data 里把材质取回来。
        used_names = {value[0] for value in materials_map.values()}
        used_materials = [bpy.data.materials[name] for name in used_names
                          if name in bpy.data.materials]
        textures = export_textures(directory, used_materials)
        result["written"].extend(path for _n, path in textures)
        result["textures"] = len(textures)
    except OSError as exc:
        result["warnings"].append(f"材质生成失败: {exc}")
        materials_map = {}

    # ---- 3) 包装场景:整个场景 + 材质覆盖 + 碰撞体 + 相机灯光 ----
    script_target = None
    for obj, physics, enabled in collect_physics(scene):
        if enabled and physics is not None and \
                getattr(physics, "script_target", False):
            script_target = obj
            break

    try:
        world_scene, body_count = write_world_scene(
            directory, "World",
            scene=scene, dimension=dimension,
            script_name=script_name if script_target else None,
            script_target_name=script_target.name if script_target else None,
            materials_map=materials_map,
        )
        result["written"].append(world_scene)
        result["bodies"] = body_count
    except OSError as exc:
        result["warnings"].append(f"包装场景生成失败: {exc}")
        return result

    # 相机 / 灯光数量(面板上要报告,用户靠这个判断"会不会又是一片灰")
    # 相机 / 灯光数量(面板上要报告,用户靠这个判断"会不会又是一片灰")
    glb_info = glb_object_names(directory, "World")
    _env, _files, _cam = build_environment_nodes(
        scene, is_3d, skip=glb_info, scene_name="World")
    result["cameras"] = len(glb_info.get("cameras", ())) or (
        1 if any(obj.type == "CAMERA" for obj in scene.objects) else 0)
    result["lights"] = len(glb_info.get("lights", ())) or (
        1 if any(obj.type == "LIGHT" for obj in scene.objects) else 0)

    # ---- 4) 角色场景(可选)----
    # 主场景已经指向 World 了,角色场景只作为"单独测试角色"用,
    # 所以 set_as_main=False,不抢主场景。
    if script_name and script_target is not None:
        bounds = object_bounds([script_target])
        try:
            scene_path, _cam, _light = write_character_scene(
                directory,
                root_name=script_target.name,
                base_class="CharacterBody3D" if is_3d else "CharacterBody2D",
                model_name="World",
                script_name=script_name,
                bounds=bounds,
                dimension=dimension,
                scene=scene,
                set_as_main=False,
            )
            result["written"].append(scene_path)
        except OSError as exc:
            result["warnings"].append(f"角色场景生成失败: {exc}")

    result["directory"] = directory
    return result


def write_character_scene(export_dir, root_name, base_class, model_name, script_name,
                          bounds, dimension="3", with_collision=True, scene=None,
                          set_as_main=True, model_dir=None):
    """生成把 模型 + 碰撞体 + 脚本 + 相机灯光 拼在一起的 .tscn。

    为什么要带相机和灯光:以前只放模型,结果按 F5 看到的**是一片灰** ——
    没有相机就没有视点,没有灯光就全黑,再加上 Godot 默认的灰底,
    看起来就像"渲染坏了"。从 Blender 场景里把相机和灯光搬过来就没这个问题。

    model_name 指哪个 .glb 来 instance。整场景导出成功时传 "World" ——
    这样角色场景里也能看到**整个场景**(地面、道具都在),而不是只有角色
    一个人悬在空中。实测踩过:不这么做的话画面里只有一个白球,地面没了。

    set_as_main=False 时不会改主场景 —— 整场景导出会先写 World 场景并设成主场景,
    之后再写角色场景时不能再抢,否则 F5 打开的就只剩角色了。
    """
    dimension_2d = str(dimension) == "2"
    sub_resources = ""
    collision = ""
    if with_collision and bounds is not None:
        size = bounds["size"]
        if dimension_2d:
            radius = max(size[0], 0.01) * 0.5
            height = max(size[1], 0.02)
        else:
            radius = max(size[0], size[2], 0.01) * 0.5
            height = max(size[1], 0.02)
        sub_resources = COLLISION_TEMPLATE.format(radius=radius, height=height)
        collision = COLLISION_NODE_2D if dimension_2d else COLLISION_NODE_3D

    # 相机 / 灯光的处理和包装场景一致:glb 里已经有就不再生成
    # (见 build_environment_nodes 的说明)。角色场景 instance 的也是
    # 那个 glb,所以它同样带着相机和灯。
    glb_info = glb_object_names(export_dir, model_name)
    environment, env_files, _camera_name = build_environment_nodes(
        scene, not dimension_2d, skip=glb_info, scene_name=model_name)
    camera_count = len(glb_info.get("cameras", ()))
    light_count = len(glb_info.get("lights", ()))

    steps = 1 + (1 if sub_resources else 0) + 2
    text = SCENE_TEMPLATE.format(
        steps=steps,
        script_path=f"res://{project.SCRIPTS_DIR}/{script_name}",
        model_path=f"res://{model_dir or project.ART_DIR}/{model_name}.glb",
        sub_resources=sub_resources,
        root_name=root_name or "Character",
        base_class=base_class,
        collision=collision,
        environment=environment,
    )
    # .tscn 统一放 scenes/(脚本在 scripts/,模型在 art/)
    path = os.path.join(export_dir, project.SCENES_DIR,
                        f"{root_name or 'Character'}.tscn")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    for relative, content in (env_files or {}).items():
        target = os.path.join(export_dir, relative)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)
    if set_as_main:
        # 顺手设成主场景,否则 Godot 里按 F5 会弹"没有设置主场景"
        project.set_main_scene(export_dir,
                               f"{project.SCENES_DIR}/{os.path.basename(path)}")
    return path, camera_count, light_count


def shader_source_dir():
    """着色器所在目录。

    必须放在**插件包内部**(BlenderGameKit/shaders/)，因为它要随扩展一起
    打包;放在仓库根目录的话，插件装进 Blender 之后就找不到了。
    """
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "shaders")


def copy_shaders(export_dir):
    """把 NPR 着色器复制进项目的 shaders/ 目录(Godot 不能引用目录外的文件)。"""
    source = shader_source_dir()
    written = []
    if not os.path.isdir(source):
        gk_log.warn(f"找不到着色器目录: {source}")
        return written
    target = os.path.join(export_dir, project.SHADERS_DIR)
    os.makedirs(target, exist_ok=True)
    for name in sorted(os.listdir(source)):
        if not name.endswith(".gdshader"):
            continue
        with open(os.path.join(source, name), "r", encoding="utf-8") as src:
            text = src.read()
        with open(os.path.join(target, name), "w", encoding="utf-8", newline="\n") as dst:
            dst.write(text)
        written.append(os.path.join(target, name))
    return written


def ensure_project_file(export_dir, project_name="BlenderGameKit Asset Export"):
    """确保目录里有 project.godot,返回它的路径。

    已存在时直接返回路径(不重写、也不返回 None),调用方不用区分
    "新建"和"已存在"两种情况。

    这里**只用** project.create_project() 那一套模板,不另写一份 ——
    早期版本这里自己拼过一个更简陋的 project.godot,和 create_project()
    写的内容不一致,两个地方都能建 project.godot 必然打架。
    """
    project.create_project(export_dir, title=project_name)
    path = os.path.join(export_dir, "project.godot")
    # create_project() 一定会把它建出来,所以这里不需要再兜底拼一份 ——
    # 曾经留着一段"如果不存在就自己写"的老代码,和模板不一致且永远不会执行。
    return path if os.path.exists(path) else None
